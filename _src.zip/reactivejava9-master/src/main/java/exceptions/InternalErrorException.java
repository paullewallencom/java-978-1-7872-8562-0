package exceptions;

public class InternalErrorException extends Exception {

	public InternalErrorException() {
		
		super("Internal error");
	}
}
